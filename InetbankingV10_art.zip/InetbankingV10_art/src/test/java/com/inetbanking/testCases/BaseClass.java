package com.inetbanking.testCases;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.inetbanking.utilites.ReadConfig;

public class BaseClass {
	ReadConfig rc = new ReadConfig();

	public static Logger log = LogManager.getLogger(BaseClass.class.getName());
	public String baseURL = rc.getBaseURL();
	public String username = rc.getusername();
	public String password = rc.getpassword();
	public static WebDriver driver;

	public static Logger logger;

	@BeforeClass
	@Parameters("browser")
	public void setup(String browser) {

		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", rc.getChromepath());
			driver = new ChromeDriver();
		}
		
		else if(browser.equalsIgnoreCase("ff")){
			System.setProperty("webdriver.gecko.driver",rc.firepath());
			driver = new FirefoxDriver();
		}
		driver.manage().window().maximize();
		driver.get(baseURL);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		log.info("Browser invoked");

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
		log.info("Browser closed");

	}
	

}
