package com.inetbanking.testCases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.inetbanking.pageObjects.LoginPage;

import junit.framework.Assert;

public class TC_LoginTest_001 extends BaseClass {

	@Test
	public void loginTest1() {
		LoginPage lp = new LoginPage(driver);
		lp.setUserName(username);
		log.info("Username is Entered");
		lp.setpwd(password);
		log.info("Password  is Entered");
		lp.clickButton();
		log.info("Clicked on submit button");

		if (driver.getTitle().equals("Guru99 Bank Manager HomePage")) {
			Assert.assertTrue(true);
			log.info("Title is correct");
		} else {
			log.error("Title is incorrect");
			Assert.assertTrue(false);
			
		}
	}

}
