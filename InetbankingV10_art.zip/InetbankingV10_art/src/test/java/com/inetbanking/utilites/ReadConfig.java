package com.inetbanking.utilites;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadConfig {
	Properties pro;

	public ReadConfig() {
		File src = new File("D:\\Eclipse_Workspace\\InetbankingV10_art\\Configuration\\config.properties");

		try {
			FileInputStream fis = new FileInputStream(src);
			pro = new Properties();
			pro.load(fis);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getBaseURL() {
		String url = pro.getProperty("baseURL");
		return url;
	}

	public String getusername() {
		String username = pro.getProperty("username");
		return username;

	}

	public String getpassword() {
		String password = pro.getProperty("password");
		return password;
	}

	public String getWebDriver() {
		String WebDriver = pro.getProperty("WebDriver");
		return WebDriver;
	}

	public String getChromepath() {
		String Chromepath = pro.getProperty("Chromepath");
		return Chromepath;
	}

	public String Iepath() {
		String Iepath = pro.getProperty("Iepath");
		return Iepath;
	}

	public String firepath() {
		String firepath = pro.getProperty("firepath");
		return firepath;
	}
	
	public String log (){
		String log = pro.getProperty("log");
		return log;
	}
}
